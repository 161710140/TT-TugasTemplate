<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rastians;

class RastianController extends Controller
{
     public function siswa(){
    $d=Rastians::all();         
    return view('database',compact('d'));
}

}