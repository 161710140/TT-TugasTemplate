<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tugas;

class erlangga extends Controller
{

    public function asiswa(){
    $c=tugas::all();        
    return view('tabel',compact('c')); 
}
}
