<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\support\facades\Schema;
class Rastians extends Model
{
    //
}
