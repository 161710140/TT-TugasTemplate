@extends('layouts.fgo')
@section('konten')

<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="1" data-slide-to="0" class="active"></li>
        <li data-target="2" data-slide-to="1"></li>
        <li data-target="3" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="item active">
          <img src="Order.jpg">
          <div class="container">
            <div class="carousel-caption">
              <h1>This is the FGO Corner!!</h1>
            </div>
          </div>
        </div>
            </div>
          </div>
        </div>
        <center>
        	<u><h2>What is FGO??</h2></u>
        	<img src="FGO.png" width="250px" height="150px">
        	<br>
        	Fate/Grand Order (フェイト/グランドオーダー, Feito/Gurando Ōdā?) is an online RPG for the iOS and Android. Referred to as the "Fate Online Project Reboot", it is a reboot of the original Fate/Apocrypha project that eventually became a novel series.
        	<u><h2>Servant</h2></u>
        	There are total of 10 servant in Grand order there is:
        	<br>
        	<br>
        	<b>Saber Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<img src="Arthur.jpg" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Archer Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Tomoe.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Lancer Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Lancer.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Rider Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Marie.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Assasin Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Sasaki.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Caster Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Tamamo.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Berserker Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Kiyohime.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Ruler Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Amakusa.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Avenger Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Jeanne.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	<b><b>Foreigner Class Servant</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</b>
        	<img src="Abigail.png" width="150px" height="250px">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        	<br>
        	<br>
        	we already know what kind of servant class in FGO but what exactly "Servant" is?
        	<br>
        	<br>
        	Servants (サーヴァント, Sāvanto?) are Heroic Spirits and Divine Spirits summoned by the Holy Grail for the purpose of competing under Masters in the Holy Grail War.
        	<br>
        	<br>
        	Servants are Heroic Spirits made into special familiars of the highest rank that are bound to the Master. Pure Heroic Spirits, the "main body" in the Throne of Heroes, can only be summoned by the World, and summoning even one is considered to be a miraculous occurrence. Differing from the normal definition of familiars that can be likened to minor mascots unable to be stronger than their masters, Heroic Spirits are the most powerful of beings with which even the five magicians would never be able to forge a contract with. Rather than it being a hard process to summon them or the fact that they far surpass magi, it is their intrinsic nature in that they are beings beyond magecraft. Magi can perform rituals to borrow their power to mimic them, but cannot summon actual Heroic Spirits themselves.
Even the Holy Grail lacks the power to summon a true Heroic Spirit, so the process is facilitated by summoning them into one of seven vessels prepared beforehand.[2] The Greater Grail makes a copy using information from the "main body" of the Heroic Spirit, an "emanation", that returns to them as information, in the form of a soul, upon the death of the Servant. Disconnected from the "main body", they are able to know of the actions of the Servant through records, as if reading a book.[1] Due to this, any Heroic Spirit summoned in multiple Holy Grail Wars will lack knowledge of previous summonings
<u><h2>Gameplay</h2></u>
The Gameplay of fate grand order is a thrilling Card Game!!!
<br>
<br>
<img src="maxresdefault (1).jpg " width="450px" height="150px">
<br>
<br>
<p>Command Cards determine the attacks your Servants perform during battle. There are three different card types: Quick, Arts, and Buster. Every player turn, you receive 5 random cards from your frontline's Command Card deck to choose for that turn. Noble Phantasms are extra cards that do not come from the deck and are available for use in addition to the 5 random cards as long as the Servant has a NP Gauge of 100% or higher.</p>
<br>
<p>Each servant possesses 5 Command Cards, and you will be sequentially distributed 5 cards from each servants respective deck for three turns so long as you have servants in the frontline; in other words, if you have 3 Servants in the frontline, you will see all 15 individual Command Cards over the course of 3 turns (meaning from Turns 1-3 you will have seen all Command Cards), after which the deck "resets" and is then redistributed to begin another cycle. In a sense this allows the player to keep track of the cards previously dealt in order to predict which cards will be drawn in the following turns before the deck resets.</p>
</center> 
<u><h2>Brave Chain</h2></u>
Quick, Arts, and Buster Chains occur when 3 of the same card type are selected. A Brave Chain occurs when all 3 cards chosen belong to the same Servant.

<li><b>Quick Chain</b>- Generate 10 Critical Stars.</li>
<li><b>Arts Chain</b> - Each Servant participating in the chain gains 20% NP Gauge.</li>
<li><b>Buster Chain</b> - Each card has 20% of a servants attack added as damage. Does not affect the extra attack from a chain nor Noble Phantasms.</li>
<li><b>Brave Chain</b>- Perform an additional attack for 200% increased damage, or 350% if the Brave Chain is also a Quick, Arts, or Buster Chain.</li>        
@endsection