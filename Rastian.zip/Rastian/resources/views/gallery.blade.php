@extends('layouts.headgallery')
@section('konten')
<div class="container">
	<u><h2>Fate Grand Order
	</h2>
</u>
<br>
<img src="q.jpg" width="150px" height="150px" class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="qa.jpg" width="150px" height="150px"  class="img-rounded" alt="d">&nbsp&nbsp&nbsp 
<img src="qs.jpg" width="150px" height="150px"  class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="qd.jpg" width="150px" height="150px"  class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="qf.jpg" width="150px" height="150px"  class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="qg.png" width="150px" height="150px"  class="img-rounded" alt="a">&nbsp&nbsp&nbsp
<br>
<u><h2>Tokyo Xanadu
	</h2>
</u>
		<br>
<img src="x.png" width="150px" height="150px" class="img-rounded" alt="a">&nbsp&nbsp&nbsp
<img src="xa.png" width="150px" height="150px"  class="img-rounded" alt="qw">&nbsp&nbsp&nbsp 
<img src="xc.png" width="150px" height="150px"  class="img-rounded" alt="e">&nbsp&nbsp&nbsp
<img src="xd.png" width="150px" height="150px"  class="img-rounded" alt="g">&nbsp&nbsp&nbsp
<img src="xf.jpg" width="150px" height="150px"  class="img-rounded" alt="k">&nbsp&nbsp&nbsp
<img src="xg.jpg" width="150px" height="150px"  class="img-rounded" alt="er">&nbsp&nbsp&nbsp
</div>
@endsection