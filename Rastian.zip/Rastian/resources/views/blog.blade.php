@extends('layouts.paragra')
@section('konten')
<br>
<br>
 <div class="blog-header">
 <center>
        <h2 class="blog-title">OTAKU</h2>
        </center>
         </div>
        <p class="lead blog-description"></p>
         <div class="row">

        <div class="col-sm-8 blog-main">
       
          <div class="blog-post">
            <u><h2 class="blog-post-title">Pengertian Otaku</h2>
            <p class="blog-post-meta">January 20, 2018 by <a href="#">Rastian</a></p>
</u>
<CENTER>
<img src="ren.png" style="position: absolute;right: -500px">
<img src="render.png" width="500px" height="707px" style="position: absolute;top: 1500px ;right:-500px">
<img src="otk.jpg" width="450px" height="250px">
</CENTER>
<br>
<br>

      <p>Otaku (おたく/オタク?) adalah istilah bahasa Jepang yang digunakan untuk menyebut orang yang betul-betul menekuni hobi.
      Sejak paruh kedua dekade 1990-an, istilah Otaku mulai dikenal di luar Jepang untuk menyebut penggemar berat subkultur asal Jepang seperti anime dan manga, bahkan ada orang yang menyebut dirinya sebagai Otaku.
      <br>
      <br>
      Otaku berasal dari sebuah istilah bahasa Jepang yang merujuk kepada rumah atau keluarga orang lain (お宅/御宅, otaku). Kata ini sering digunakan sebagai metafora untuk honorifik kata ganti orang kedua. Dalam kasus ini, terjemahannya adalah "Anda". Sebagai contoh, dalam anime Macross, ditayangkan pertama kali pada tahun 1982, tokoh Lynn Minmay menggunakan istilah ini sebagai kata ganti.[1][2]
      Bentuk slang modern dari otaku ditulis sepenuhnya dengan aksara hiragana (おたく) atau katakana (オタク, atau yang lebih jarang, ヲタク) untuk membedakan dengan makna terdahulunya. Istilah ini kemungkinan besar berasal dari percakapan antar penggemar anime yang selalu menyapa lawan bicara dengan sebutan Otaku (お宅 Anda?).</p>
            <div class="blog-post">
            <u><h2 class="blog-post-title">Sejarah</h2>
Di awal dekade 1980-an sudah ada istilah slang bernada sumbang byōki (ビョーキ "sakit"?) yang ditujukan kepada penggemar berat lolicon, manga dan dōjin manga. Istilah byōki sudah sering muncul dalam dōjinshi sampai ke anime dengan peran utama anak perempuan seperti Minky Momo.
Istilah otaku pertama kali diperkenalkan oleh kolumnis Nakamori Akio dalam artikel "Otaku" no Kenkyū (おたくの研究 Penelitian tentang Otaku?)[1] yang dimuat majalah Manga Burikko. Dalam artikel yang dimuat bersambung dari bulan Juni hingga Desember 1983, istilah otaku digunakan untuk menyebut penggemar berat subkultur seperti anime dan manga.
Pada waktu itu, masyarakat umum sama sekali belum mengenal istilah otaku. Media massa yang pertama kali menggunakan istilah otaku adalah radio Nippon Broadcasting System yang mengangkat segmen Otakuzoku no jittai (おたく族の実態 situasi kalangan otaku?) pada acara radio Young Paradise. Istilah Otakuzoku (secara harafiah: suku Otaku) digunakan untuk menyebut kalangan otaku, mengikuti sebutan yang sudah ada untuk kelompok anak muda yang memakai akhiran kata "zoku," seperti Bōsōzoku dan Takenokozoku.
Pada perkembangan selanjutnya, sebutan otaku digunakan untuk pria lajang yang mempunyai hobi anime, manga, idol, permainan video, dan komputer pribadi tanpa mengenal batasan umur. Istilah otaku juga banyak dipakai untuk menyebut wanita lajang atau wanita sudah menikah yang membentuk kelompok sedikit bersifat "cult" berdasarkan persamaan hobi. Kalangan yang berusia 50 tahun ke atas yang merupakan penggemar berat high culture atau terus mengejar prestasi di bidang akademis jarang sekali dan hampir tidak pernah disebut otaku.
Istilah "otaku" dalam arti sempit awalnya hanya digunakan di antara orang-orang yang memiliki hobi sejenis yang membentuk kalangan terbatas seperti penerbitan Dōjinshi. Belakangan ini, istilah otaku dalam arti luas sering dapat mempunyai konotasi negatif atau positif bergantung pada situasi dan orang yang menggunakannya. Istilah otaku secara negatif digunakan untuk penggemar fanatik suatu subkultur yang letak bagusnya tidak bisa dimengerti masyarakat umum, atau orang yang kurang mampu berkomunikasi dan sering tidak mau bergaul dengan orang lain. Otaku secara positif digunakan untuk menyebut orang yang sangat mendalami suatu bidang hingga mendetil, bersamaan dengan tingkat pengetahuan yang sangat tinggi hingga mencapai tingkat pakar dalam bidang tersebut.
Sebelum istilah otaku menjadi populer di Jepang, sudah ada orang yang disebut "mania" karena hanya menekuni sesuatu dan tidak mempunyai minat pada kehidupan sehari-hari yang biasa dilakukan orang. Di Jepang, istilah otaku sering digunakan di luar konteks penggemar berat anime atau manga untuk menggantikan istilah mania, sehingga ada istilah Game-otaku, Gundam-otaku (otaku mengenai robot Gundam), Gunji-otaku (otaku bidang militer), Pasokon-otaku (otaku komputer), Tetsudō-otaku (otaku kereta api alias Tecchan), Morning Musume-otaku (otaku Morning Musume alias Mō-ota), Jani-ota (otaku penyanyi keren yang tergabung dalam Johnny & Associates).
<br>
<br>
<img src="119.jpg" class="img-rounded" width="350px" height="250px">
<img src="118.jpg" class="img-rounded" width="350px" height="250px">
<br>
<br>
Secara derogatif, istilah otaku banyak digunakan orang sebagai sebutan bagi "laki-laki dengan kebiasaan aneh dan tidak dimengerti masyarakat umum," tanpa memandang orang tersebut menekuni suatu hobi atau tidak. Anak perempuan di Jepang sering menggunakan istilah otaku untuk anak laki-laki yang tidak populer di kalangan anak perempuan, tetapi sebaliknya istilah ini tidak pernah digunakan untuk perempuan. Berhubung istilah otaku sering digunakan dalam konteks yang menyinggung perasaan, penggunaan istilah otaku sering dikritik sebagai praduga atau perlakuan diskriminasi terhadap seseorang.
Otaku juga identik dengan sebutan Akiba Kei yang digunakan untuk laki-laki yang berselera buruk dalam soal berpakaian. Sebutan Akiba Kei berasal dari gaya berpakaian laki-laki yang lebih suka mengeluarkan uang untuk keperluan hobi di distrik Akihabara, Tokyo daripada membeli baju yang sedang tren. Sebutan lain yang kurang umum untuk Akiba-Kei adalah A-Boy atau A-Kei, mengikuti istilah B-Boy (B-Kei atau B-Kaji) yang sudah lebih dulu ada untuk orang yang meniru penampilan penyanyi hip-hop berkulit hitam.
@endsection