
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" lang="en-US" prefix="og: http://ogp.me/ns#">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noarchive" />
<meta name="google-site-verification" content="GtbKoJumjWhXM3tQLjGLEjG-mbD-6Rz9RVb40AdZqsM" />

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-TT2ZL6N');</script>


<script type="text/javascript">
			 (function () {
				var s = document.createElement('script');
				s.type = 'text/javascript';
				s.async = true;
				s.src = ('https:' == document.location.protocol ? 'https://s' : 'http://i')
				  + '.po.st/static/v4/post-widget.js#publisherKey=2qjv0i4ur15g9qtuct54';
				var x = document.getElementsByTagName('script')[0];
				x.parentNode.insertBefore(s, x);
			 })();
		</script>

<link rel="icon" type="image/png" href="https://gematsu.com/wp-content/themes/2014/images/favicon.png" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://gematsu.com/wp-content/themes/2014/style.css" type="text/css" />
<link rel="pingback" href="https://gematsu.com/xmlrpc.php" />

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="https://gematsu.com/wp-content/themes/2014/js/slides.min.jquery.js"></script>

<script>
	var _comscore = _comscore || [];
	_comscore.push({ c1: "2", c2: "24936062" });
	(function() {
	var s = document.createElement("script"), el =
	document.getElementsByTagName("script")[0]; s.async = true;
	s.src = (document.location.protocol == "https:" ? "https://sb" :
	"http://b") + ".scorecardresearch.com/beacon.js";
	el.parentNode.insertBefore(s, el);
	})();
	</script>
<noscript>
	<img src="http://b.scorecardresearch.com/p?
	c1=2&c2=24936062&cv=2.0&cj=1" />
	</noscript>

<style type="text/css">
		#fancybox-close{right:-15px;top:-15px}
		div#fancybox-content{border-color:#0f0f0f}
		div#fancybox-title{background-color:#0f0f0f}
		div#fancybox-outer{background-color:#0f0f0f}
		div#fancybox-title-inside{color:#ffffff}
	</style>

<title>The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan - Gematsu</title>
<link rel="canonical" href="https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan - Gematsu" />
<meta property="og:description" content="Falcom has officially announced The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ for PlayStation 4. It will launch in Japan in fall 2018. Here is a brief overview of the game, via Falcom: (Editor&#8217;s Note: It goes without saying, but any The Legend of Heroes: Trails of Cold Steel IV &hellip;" />
<meta property="og:url" content="https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan" />
<meta property="og:site_name" content="Gematsu" />
<meta property="article:tag" content="Falcom" />
<meta property="article:tag" content="Game Announce" />
<meta property="article:tag" content="RPG" />
<meta property="article:tag" content="Screenshots" />
<meta property="article:tag" content="The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~" />
<meta property="article:section" content="PlayStation 4" />
<meta property="article:published_time" content="2017-12-20T01:26:25-05:00" />
<meta property="article:modified_time" content="2017-12-20T22:54:52-05:00" />
<meta property="og:updated_time" content="2017-12-20T22:54:52-05:00" />
<meta property="og:image" content="https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17.jpg" />
<meta property="og:image:secure_url" content="https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17.jpg" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="337" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Falcom has officially announced The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ for PlayStation 4. It will launch in Japan in fall 2018. Here is a brief overview of the game, via Falcom: (Editor&#8217;s Note: It goes without saying, but any The Legend of Heroes: Trails of Cold Steel IV [&hellip;]" />
<meta name="twitter:title" content="The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan - Gematsu" />
<meta name="twitter:image" content="https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17.jpg" />
<meta name="twitter:creator" content="@salromano" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/gematsu.com\/","name":"Gematsu","potentialAction":{"@type":"SearchAction","target":"https:\/\/gematsu.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>

<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Gematsu &raquo; Feed" href="https://gematsu.com/feed" />
<link rel="alternate" type="application/rss+xml" title="Gematsu &raquo; Comments Feed" href="https://gematsu.com/comments/feed" />
<link rel="alternate" type="application/rss+xml" title="Gematsu &raquo; The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan Comments Feed" href="https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan/feed" />
<link rel='stylesheet' id='fancybox-css' href='https://gematsu.com/wp-content/plugins/fancybox-for-wordpress/fancybox/fancybox.css?ver=4.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-polls-css' href='https://gematsu.com/wp-content/plugins/wp-polls/polls-css.css?ver=2.73.8' type='text/css' media='all' />
<style id='wp-polls-inline-css' type='text/css'>
.wp-polls .pollbar {
	margin: 1px;
	font-size: 3px;
	line-height: 5px;
	height: 5px;
	background: #005484;
	border: 1px solid #ffffff;
}

</style>
<link rel='stylesheet' id='jetpack_css-css' href='https://gematsu.com/wp-content/plugins/jetpack/css/jetpack.css?ver=5.7' type='text/css' media='all' />
<script type='text/javascript' src='https://gematsu.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://gematsu.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://gematsu.com/wp-content/plugins/fancybox-for-wordpress/fancybox/jquery.fancybox.js?ver=1.3.8'></script>
<link rel='https://api.w.org/' href='https://gematsu.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://gematsu.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://gematsu.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 4.9.2" />
<link rel='shortlink' href='https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan' />
<link rel="alternate" type="application/json+oembed" href="https://gematsu.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgematsu.com%2F2017%2F12%2Flegend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan" />
<link rel="alternate" type="text/xml+oembed" href="https://gematsu.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgematsu.com%2F2017%2F12%2Flegend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan&#038;format=xml" />

<script type="text/javascript">
jQuery(function(){

jQuery.fn.getTitle = function() { // Copy the title of every IMG tag and add it to its parent A so that fancybox can show titles
	var arr = jQuery("a.fancybox");
	jQuery.each(arr, function() {
		var title = jQuery(this).children("img").attr("title");
		jQuery(this).attr('title',title);
	})
}

// Supported file extensions
var thumbnails = jQuery("a:has(img)").not(".nolightbox").filter( function() { return /\.(jpe?g|png|gif|bmp)$/i.test(jQuery(this).attr('href')) });

thumbnails.addClass("fancybox").attr("rel","fancybox").getTitle();
jQuery("a.fancybox").fancybox({
	'cyclic': false,
	'autoScale': true,
	'padding': 5,
	'opacity': true,
	'speedIn': 500,
	'speedOut': 500,
	'changeSpeed': 300,
	'overlayShow': true,
	'overlayOpacity': "0.3",
	'overlayColor': "#666666",
	'titleShow': true,
	'titlePosition': 'inside',
	'enableEscapeButton': true,
	'showCloseButton': true,
	'showNavArrows': true,
	'hideOnOverlayClick': true,
	'hideOnContentClick': false,
	'width': 560,
	'height': 340,
	'transitionIn': "elastic",
	'transitionOut': "fade",
	'centerOnScroll': true
});


})
</script>

</head>
<body>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TT2ZL6N"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<div id="sitewrap">

<div id="div-gpt-ad-1506639509730-0"></div>
<style type="text/css">
	#header, #a728, #featured { position: relative; }
	</style>
<div id="header">
<div class="containwidth">

<a href="/"><div id="logo"></div></a>

<div id="navigation">
<ul>
<a href="/c/playstation-4"><li class="navitem">PS4</li></a>
<a href="/c/xbox-one"><li class="navitem">XBO</li></a>
<a href="/c/switch"><li class="navitem">Switch</li></a>
<a href="/c/3ds"><li class="navitem">3DS</li></a>
<a href="/c/playstation-vita"><li class="navitem">Vita</li></a>
<a href="/c/pc"><li class="navitem">PC</li></a>
<a href="/c/playstation-3"><li class="navitem">PS3</li></a>
<div id="browsegames">
<div class="browsegamestop">
<span>Browse<br>Games</span>
<div class="browsegames">
<div class="trackexclusives">
<a href="/exclusives/"><div>Track Exclusives Across PS4, Xbox One, Switch, 3DS, PS Vita, and more</div></a>
</div>
<ul>
<a href="https://gematsu.com/tag/ace-combat-7-skies-unknown"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_ace-combat-7.png);">Ace Combat 7: Skies Unknown</li></a>
<a href="https://gematsu.com/tag/a-certain-magical-virtual-on"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_a-certain-magical-virtual-on.png);">A Certain Magical Virtual-On</li></a>
<a href="https://gematsu.com/tag/atelier-lydie-suelle-the-alchemists-and-the-mysterious-paintings"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_atelier-lydie-soeur-alchemists-of-the-mysterious-painting.png);">Atelier Lydie & Suelle: The Alchemists and...</li></a>
<a href="https://gematsu.com/tag/biomutant"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_biomutant.png);">Biomutant</li></a>
<a href="https://gematsu.com/tag/blazblue-cross-tag-battle"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_blazblue-cross-tag-battle.png);">BlazBlue: Cross Tag Battle</li></a>
<a href="https://gematsu.com/tag/the-caligula-effect-overdose"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_the-caligula-effect-overdose.png);">The Caligula Effect: Overdose</li></a>
<a href="https://gematsu.com/tag/catherine-full-body"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_catherine-full-body.png);">Catherine: Full Body</li></a>
<a href="https://gematsu.com/tag/code-vein"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_code-vein.png);">Code Vein</li></a>
<a href="https://gematsu.com/tag/death-end-re-quest"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_death-end-re-quest.png);">Death end re;Quest</li></a>
<a href="https://gematsu.com/tag/death-stranding"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_death-stranding.png);">Death Stranding</li></a>
<a href="https://gematsu.com/tag/digimon-story-cyber-sleuth-hackers-memory"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_digimon-story-cyber-sleuth-hackers-memory.png);">Digimon Story: Cyber Sleuth Hacker's...</li></a>
<a href="https://gematsu.com/tag/disaster-report-4-plus-summer-memories"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_disaster-report-4-plus.png);">Disaster Report 4 Plus</li></a>
<a href="https://gematsu.com/tag/dissidia-final-fantasy-nt"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_dissidia-final-fantasy-nt.png);">Dissidia Final Fantasy NT</li></a>
<a href="https://gematsu.com/tag/dragon-ball-fighterz"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_dragon-ball-fighterz.png);">Dragon Ball FighterZ</li></a>
<a href="https://gematsu.com/tag/dragon-quest-xi-echoes-of-an-elusive-age"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_dragon-quest-xi.png);">Dragon Quest XI: Echoes of an Elusive Age</li></a>
<a href="https://gematsu.com/tag/dynasty-warriors-9"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_dynasty-warriors-9.png);">Dynasty Warriors 9</li></a>
<a href="https://gematsu.com/tag/earth-defense-force-5"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_earth-defense-force-5.png);">Earth Defense Force 5</li></a>
<a href="https://gematsu.com/tag/fate-extella-link"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_fate-extella-link.png);">Fate/Extella Link</li></a>
<a href="https://gematsu.com/tag/final-fantasy-vii-remake"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_final-fantasy-vii-remake.png);">Final Fantasy VII Remake</li></a>
<a href="https://gematsu.com/tag/final-fantasy-xv"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_final-fantasy-xv.png);">Final Fantasy XV</li></a>
<a href="https://gematsu.com/tag/girls-und-panzer-dream-tank-match"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_girls-und-panzer-dream-tank-match.png);">Girls und Panzer: Dream Tank Match</li></a>
<a href="https://gematsu.com/tag/god-eater-3"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_god-eater-3.png);">God Eater 3</li></a>
<a href="https://gematsu.com/tag/granblue-fantasy-project-re-link"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_granblue-fantasy-project-re-link.png);">Granblue Fantasy Project Re: Link</li></a>
<a href="https://gematsu.com/tag/gundam-versus"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_gundam-versus.png);">Gundam Versus</li></a>
<a href="https://gematsu.com/tag/hokuto-ga-gotoku"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_hokuto-ga-gotoku.png);">Hokuto ga Gotoku</li></a>
<a href="https://gematsu.com/tag/kingdom-hearts-iii"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_kingdom-hearts-iii.png);">Kingdom Hearts III</li></a>
<a href="https://gematsu.com/tag/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga.png);">The Legend of Heroes: Trails of Cold Steel IV</li></a>
<a href="https://gematsu.com/tag/little-witch-academia-chamber-of-time"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_little-witch-academia-chamber-of-time.png);">Little Witch Academia: Chamber of Time</li></a>
<a href="https://gematsu.com/tag/metal-max-xeno"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_metal-max-xeno.png);">Metal Max Xeno</li></a>
<a href="https://gematsu.com/tag/monster-hunter-world"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_monster-hunter-world.png);">Monster Hunter: World</li></a>
<a href="https://gematsu.com/tag/my-hero-academia-ones-justice"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_my-hero-academia-ones-justice.png);">My Hero Academia: One's Justice</li></a>
<a href="https://gematsu.com/tag/ni-no-kuni-ii-revenant-kingdom"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_ni-no-kuni-ii-revenant-kingdom.png);">Ni no Kuni II: Revenant Kingdom</li></a>
<a href="https://gematsu.com/tag/left-alive"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_left-alive.png);">Left Alive</li></a>
<a href="https://gematsu.com/tag/persona-3-dancing-moon-night+persona-5-dancing-star-night"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_persona-3-5-dancing.png);">Persona 3 / 5 Dancing</li></a>
<a href="https://gematsu.com/tag/secret-of-mana"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_secret-of-mana.png);">Secret of Mana</li></a>
<a href="https://gematsu.com/tag/senran-kagura-burst-re-newal"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_senran-kagura-burst-re-newal.png);">Senran Kagura Burst Re:Newal</li></a>
<a href="https://gematsu.com/tag/shenmue-iii"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_shenmue-iii.png);">Shenmue III</li></a>
<a href="https://gematsu.com/tag/shin-megami-tensei-v"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_shin-megami-tensei-v.png);">Shin Megami Tensei V</li></a>
<a href="https://gematsu.com/tag/soulcalibur-vi"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_soulcalibur-vi.png);">Soulcalibur VI</li></a>
<a href="https://gematsu.com/tag/street-fighter-v"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_street-fighter-v.png);">Street Fighter V</li></a>
<a href="https://gematsu.com/tag/sword-art-online-fatal-bullet"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_sword-art-online-fatal-bullet.png);">Sword Art Online: Fatal Bullet</li></a>
<a href="https://gematsu.com/tag/travis-strikes-again-no-more-heroes"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_travis-strikes-again-no-more-heroes.png);">Travis Strikes Again: No More Heroes</li></a>
<a href="https://gematsu.com/tag/valkyria-chronicles-4"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_valkyria-chronicles-4.png);">Valkyria Chronicles 4</li></a>
<a href="https://gematsu.com/tag/yakuza-kiwami-2"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_yakuza-kiwami-2.png);">Yakuza: Kiwami 2</li></a>
<a href="https://gematsu.com/tag/yakuza-6-the-song-of-life"><li style="background-image: url(https://gematsu.com/wp-content/themes/2014/images/populargames/populargames_yakuza-6.png);">Yakuza 6: The Song of Life</li></a>
<div class="clear"></div>
</ul>
</div>
</div>
<div class="clear"></div>
</div> </ul>
</div>

<form action="https://gematsu.com" id="searchform" method="get">
<input type="text" id="s" name="s" value="" />
<input type="submit" value="&rarr;" id="searchsubmit" />
</form>

<div id="ucp">
<ul>
<li class="ucptop"><img src="https://gematsu.com/wp-content/themes/2014/images/ucp.png">
<ul>

<a href="https://gematsu.com/wp-login.php?redirect_to=/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan" class="simplemodal-login"><li>Log In</li></a>
<a href="https://gematsu.com/wp-login.php?action=register" class="simplemodal-register"><li class="last">Register</li></a>
</ul>
</li>
</ul>
</div>
<div class="clear"></div>
</div>
</div>

<div id="a728" class="advertisement">
<div class="a728">

<div id="div-gpt-ad-1506639509730-4"></div>
</div>
</div>

<div id="featured" class="single">
<div class="containwidth">
<div id="featsingle">
<div class="idTabs">
<a href="#latestnews">Latest News</a>
<a href="#topstories">Top Stories</a>
<a href="#rpgnews">RPG News</a>
<a href="#fightinggamenews">Fighting Game News</a>
<a href="#releasedates">Release Dates</a>
<a href="#videos">Videos</a>
<a href="#gameannounce">New Game Announcements</a>
</div>
<div class="clear"></div>
<div style="height: 134px; overflow: hidden;">

<div id="latestnews">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/open-forum-287" title="Open Forum #287" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Open-Forum-287-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Open Forum #287" srcset="https://gematsu.com/wp-content/uploads/2018/01/Open-Forum-287-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Open-Forum-287-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/open-forum-287" title="Open Forum #287" rel="bookmark">Open Forum #287</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/digimon-rearise-first-screenshots-teaser-website-opened" title="Digimon ReArise first screenshots, teaser website opened" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Digimon-ReArise_01-20-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Digimon ReArise" srcset="https://gematsu.com/wp-content/uploads/2018/01/Digimon-ReArise_01-20-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Digimon-ReArise_01-20-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/digimon-rearise-first-screenshots-teaser-website-opened" title="Digimon ReArise first screenshots, teaser website opened" rel="bookmark">Digimon ReArise first screenshots, teaser web...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition" title="Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Final Fantasy VII Remake" srcset="https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition" title="Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition" rel="bookmark">Final Fantasy VII Remake concept art debuts a...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Ys VIII: Lacrimosa of Dana" srcset="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark">Ys VIII for PC delayed to unannounced date</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/netflix-castlevania-animated-series-season-two-premieres-summer" title="Netflix Castlevania animated series season two premieres this summer" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Castlevania-Netflix_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Castlevania" srcset="https://gematsu.com/wp-content/uploads/2018/01/Castlevania-Netflix_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Castlevania-Netflix_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/netflix-castlevania-animated-series-season-two-premieres-summer" title="Netflix Castlevania animated series season two premieres this summer" rel="bookmark">Netflix Castlevania animated series season tw...</a></div>
</div>
<div class="clear"></div>
</div>

<div id="topstories">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/new-gundam-breaker-announced-ps4" title="New Gundam Breaker announced for PS4 [Update 2: coming west]" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/New-Gundam-Breaker-Ann_01-16-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="New Gundam Breaker" srcset="https://gematsu.com/wp-content/uploads/2018/01/New-Gundam-Breaker-Ann_01-16-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/New-Gundam-Breaker-Ann_01-16-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/new-gundam-breaker-announced-ps4" title="New Gundam Breaker announced for PS4 [Update 2: coming west]" rel="bookmark">New Gundam Breaker announced for PS4 [Update ...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/final-fantasy-xv-royal-edition-announced-launches-alongside-windows-edition-march-6" title="Final Fantasy XV Royal Edition announced, launches alongside Windows Edition on March 6" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/FFXV-Royal-Edition_01-16-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Final Fantasy XV Royal Edition" srcset="https://gematsu.com/wp-content/uploads/2018/01/FFXV-Royal-Edition_01-16-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/FFXV-Royal-Edition_01-16-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/final-fantasy-xv-royal-edition-announced-launches-alongside-windows-edition-march-6" title="Final Fantasy XV Royal Edition announced, launches alongside Windows Edition on March 6" rel="bookmark">Final Fantasy XV Royal Edition announced, lau...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/final-fantasy-xii-zodiac-age-coming-pc-via-steam-february-1" title="Final Fantasy XII: The Zodiac Age coming to PC via Steam on February 1" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/FF12-Steam-Ann_01-11-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Final Fantasy XII: The Zodiac Age" srcset="https://gematsu.com/wp-content/uploads/2018/01/FF12-Steam-Ann_01-11-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/FF12-Steam-Ann_01-11-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/final-fantasy-xii-zodiac-age-coming-pc-via-steam-february-1" title="Final Fantasy XII: The Zodiac Age coming to PC via Steam on February 1" rel="bookmark">Final Fantasy XII: The Zodiac Age coming to P...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/dark-souls-remastered-announced-ps4-xbox-one-switch-pc" title="Dark Souls Remastered announced for PS4, Xbox One, Switch, and PC" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/DS-Remaster_01-11-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Dark Souls Remastered" srcset="https://gematsu.com/wp-content/uploads/2018/01/DS-Remaster_01-11-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/DS-Remaster_01-11-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/dark-souls-remastered-announced-ps4-xbox-one-switch-pc" title="Dark Souls Remastered announced for PS4, Xbox One, Switch, and PC" rel="bookmark">Dark Souls Remastered announced for PS4, Xbox...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/snk-heroines-tag-team-frenzy-announced-switch-ps4" title="SNK Heroines: Tag Team Frenzy announced for Switch, PS4" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/SNK-Heroines_01-11-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="SNK Heroines: Tag Team Frenzy" srcset="https://gematsu.com/wp-content/uploads/2018/01/SNK-Heroines_01-11-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/SNK-Heroines_01-11-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/snk-heroines-tag-team-frenzy-announced-switch-ps4" title="SNK Heroines: Tag Team Frenzy announced for Switch, PS4" rel="bookmark">SNK Heroines: Tag Team Frenzy announced for S...</a></div>
</div>
<div class="clear"></div>
</div>

<div id="rpgnews">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition" title="Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Final Fantasy VII Remake" srcset="https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/FFVII-Remake-Art-Junshen_01-20-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition" title="Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition" rel="bookmark">Final Fantasy VII Remake concept art debuts a...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Ys VIII: Lacrimosa of Dana" srcset="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark">Ys VIII for PC delayed to unannounced date</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/post-final-fantasy-x-2-tidus-yuna-illustrations-debut-final-fantasy-30th-anniversary-exhibition" title="Post-Final Fantasy X-2 Tidus and Yuna illustrations debut at Final Fantasy 30th Anniversary Exhibition" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Final-Fantasy-X-2-Illust_2018_01-19-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Final Fantasy X | X-2 HD Remaster" srcset="https://gematsu.com/wp-content/uploads/2018/01/Final-Fantasy-X-2-Illust_2018_01-19-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Final-Fantasy-X-2-Illust_2018_01-19-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/post-final-fantasy-x-2-tidus-yuna-illustrations-debut-final-fantasy-30th-anniversary-exhibition" title="Post-Final Fantasy X-2 Tidus and Yuna illustrations debut at Final Fantasy 30th Anniversary Exhibition" rel="bookmark">Post-Final Fantasy X-2 Tidus and Yuna illustr...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/sword-art-online-fatal-bullet-details-argo-daisy-yui-rain-philia-lisbeths-workshop" title="Sword Art Online: Fatal Bullet details Argo, Daisy, Yui, Rain, Philia, Lisbeth&#8217;s Workshop, more" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Sword-Art-Online-Fatal-Bullet_2018_01-19-18_011-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="" srcset="https://gematsu.com/wp-content/uploads/2018/01/Sword-Art-Online-Fatal-Bullet_2018_01-19-18_011-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Sword-Art-Online-Fatal-Bullet_2018_01-19-18_011-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/sword-art-online-fatal-bullet-details-argo-daisy-yui-rain-philia-lisbeths-workshop" title="Sword Art Online: Fatal Bullet details Argo, Daisy, Yui, Rain, Philia, Lisbeth&#8217;s Workshop, more" rel="bookmark">Sword Art Online: Fatal Bullet details Argo, ...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/valkyria-chronicles-4-japanese-first-print-limited-edition-bonus-missions-dlc-trailer" title="Valkyria Chronicles 4 Japanese first-print and limited edition bonus missions DLC trailer" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Valkyria Chronicles 4" srcset="https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/valkyria-chronicles-4-japanese-first-print-limited-edition-bonus-missions-dlc-trailer" title="Valkyria Chronicles 4 Japanese first-print and limited edition bonus missions DLC trailer" rel="bookmark">Valkyria Chronicles 4 Japanese first-print an...</a></div>
</div>
<div class="clear"></div>
</div>

<div id="fightinggamenews">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/hero-academia-ones-justice-adds-might" title="My Hero Academia: One&#8217;s Justice adds All Might" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/MHAOJ-Scan_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="My Hero Academia: One&#039;s Justice" srcset="https://gematsu.com/wp-content/uploads/2018/01/MHAOJ-Scan_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/MHAOJ-Scan_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/hero-academia-ones-justice-adds-might" title="My Hero Academia: One&#8217;s Justice adds All Might" rel="bookmark">My Hero Academia: One&#8217;s Justice adds Al...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-adds-playable-android-21" title="Dragon Ball FighterZ adds playable Android 21" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Android-21-Scan_01-17-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Dragon Ball FighterZ" srcset="https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Android-21-Scan_01-17-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Android-21-Scan_01-17-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-adds-playable-android-21" title="Dragon Ball FighterZ adds playable Android 21" rel="bookmark">Dragon Ball FighterZ adds playable Android 21</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-open-beta-round-two-set-january-18-19" title="Dragon Ball FighterZ open beta round two set for January 18 to 19" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Open-Beta-R2_01-17-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Dragon Ball FighterZ" srcset="https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Open-Beta-R2_01-17-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/DB-FighterZ-Open-Beta-R2_01-17-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-open-beta-round-two-set-january-18-19" title="Dragon Ball FighterZ open beta round two set for January 18 to 19" rel="bookmark">Dragon Ball FighterZ open beta round two set ...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/blazblue-cross-tag-battle-launches-may-31-japan-asia-june-5-north-america-adds-dlc-character-blake-belladonna" title="BlazBlue: Cross Tag Battle launches May 31 in Japan and Asia, June 5 in North America; adds DLC character Blake Belladonna" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/BlazBlue-CTB_01-13-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="BlazBlue: Cross Tag Battle" srcset="https://gematsu.com/wp-content/uploads/2018/01/BlazBlue-CTB_01-13-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/BlazBlue-CTB_01-13-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/blazblue-cross-tag-battle-launches-may-31-japan-asia-june-5-north-america-adds-dlc-character-blake-belladonna" title="BlazBlue: Cross Tag Battle launches May 31 in Japan and Asia, June 5 in North America; adds DLC character Blake Belladonna" rel="bookmark">BlazBlue: Cross Tag Battle launches May 31 in...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-beerus-trailer" title="Dragon Ball FighterZ Beerus trailer" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Dragon-Ball-FighterZ-PV_01-12-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Dragon Ball FighterZ" srcset="https://gematsu.com/wp-content/uploads/2018/01/Dragon-Ball-FighterZ-PV_01-12-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Dragon-Ball-FighterZ-PV_01-12-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/dragon-ball-fighterz-beerus-trailer" title="Dragon Ball FighterZ Beerus trailer" rel="bookmark">Dragon Ball FighterZ Beerus trailer</a></div>
</div>
<div class="clear"></div>
</div>

<div id="releasedates">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Ys VIII: Lacrimosa of Dana" srcset="https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Ys-VIII-PC-Delay_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2" title="Ys VIII for PC delayed to unannounced date" rel="bookmark">Ys VIII for PC delayed to unannounced date</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/neo-atlas-1469-coming-switch-april-19-japan" title="Neo Atlas 1469 coming to Switch on April 19 in Japan" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Neo-Atlas-1469-Switch-Announce_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Neo Atlas 1469" srcset="https://gematsu.com/wp-content/uploads/2018/01/Neo-Atlas-1469-Switch-Announce_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Neo-Atlas-1469-Switch-Announce_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/neo-atlas-1469-coming-switch-april-19-japan" title="Neo Atlas 1469 coming to Switch on April 19 in Japan" rel="bookmark">Neo Atlas 1469 coming to Switch on April 19 i...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/witch-hundred-knight-2-launches-march-27-north-america-march-30-europe" title="The Witch and the Hundred Knight 2 launches March 27 in North America, March 30 in Europe" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Witch-Hundred-Knight-2-Date_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="The Witch and the Hundred Knight 2" srcset="https://gematsu.com/wp-content/uploads/2018/01/Witch-Hundred-Knight-2-Date_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Witch-Hundred-Knight-2-Date_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/witch-hundred-knight-2-launches-march-27-north-america-march-30-europe" title="The Witch and the Hundred Knight 2 launches March 27 in North America, March 30 in Europe" rel="bookmark">The Witch and the Hundred Knight 2 launches M...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/battlefield-1-expansion-apocalypse-launches-february" title="Battlefield 1 expansion &#8216;Apocalypse&#8217; launches in February" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/BF1-Apocalypse-Feb_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Battlefield 1" srcset="https://gematsu.com/wp-content/uploads/2018/01/BF1-Apocalypse-Feb_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/BF1-Apocalypse-Feb_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/battlefield-1-expansion-apocalypse-launches-february" title="Battlefield 1 expansion &#8216;Apocalypse&#8217; launches in February" rel="bookmark">Battlefield 1 expansion &#8216;Apocalypse&#82...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/life-strange-storm-physical-editions-launch-march-6-north-america-march-9-europe-alongside-farewell-bonus-episode" title="Life is Strange: Before the Storm physical editions launch March 6 in North America, March 9 in Europe alongside &#8216;Farewell&#8217; bonus episode" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Life-is-Strange-Before-the-Storm_2018_01-18-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Life is Strange: Before the Storm" srcset="https://gematsu.com/wp-content/uploads/2018/01/Life-is-Strange-Before-the-Storm_2018_01-18-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Life-is-Strange-Before-the-Storm_2018_01-18-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/life-strange-storm-physical-editions-launch-march-6-north-america-march-9-europe-alongside-farewell-bonus-episode" title="Life is Strange: Before the Storm physical editions launch March 6 in North America, March 9 in Europe alongside &#8216;Farewell&#8217; bonus episode" rel="bookmark">Life is Strange: Before the Storm physical ed...</a></div>
</div>
<div class="clear"></div>
</div>

<div id="videos">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/persona-4-dancing-night-ps4-first-gameplay-video" title="Persona 4: Dancing All Night for PS4 first gameplay video" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/P4D-PS4-Gameplay_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Persona 4: Dancing All Night" srcset="https://gematsu.com/wp-content/uploads/2018/01/P4D-PS4-Gameplay_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/P4D-PS4-Gameplay_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/persona-4-dancing-night-ps4-first-gameplay-video" title="Persona 4: Dancing All Night for PS4 first gameplay video" rel="bookmark">Persona 4: Dancing All Night for PS4 first ga...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/happy-delayed-summer-adds-second-playable-character" title="We Happy Few delayed to summer, adds second playable character" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/We-Happy-Few_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="We Happy Few" srcset="https://gematsu.com/wp-content/uploads/2018/01/We-Happy-Few_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/We-Happy-Few_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/happy-delayed-summer-adds-second-playable-character" title="We Happy Few delayed to summer, adds second playable character" rel="bookmark">We Happy Few delayed to summer, adds second p...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/dynasty-warriors-9-playing-around-open-world-gameplay-video" title="Dynasty Warriors 9 &#8216;Playing Around in the Open World&#8217; gameplay video" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/DW9-Gameplay_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Dynasty Warriors 9" srcset="https://gematsu.com/wp-content/uploads/2018/01/DW9-Gameplay_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/DW9-Gameplay_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/dynasty-warriors-9-playing-around-open-world-gameplay-video" title="Dynasty Warriors 9 &#8216;Playing Around in the Open World&#8217; gameplay video" rel="bookmark">Dynasty Warriors 9 &#8216;Playing Around in t...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/valkyria-chronicles-4-japanese-first-print-limited-edition-bonus-missions-dlc-trailer" title="Valkyria Chronicles 4 Japanese first-print and limited edition bonus missions DLC trailer" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Valkyria Chronicles 4" srcset="https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Valkyria-Chronicles-4-PV_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/valkyria-chronicles-4-japanese-first-print-limited-edition-bonus-missions-dlc-trailer" title="Valkyria Chronicles 4 Japanese first-print and limited edition bonus missions DLC trailer" rel="bookmark">Valkyria Chronicles 4 Japanese first-print an...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/koei-tecmo-attack-titan-2-switch-ps-vita-gameplay-trailers" title="Koei Tecmo’s Attack on Titan 2 Switch and PS Vita gameplay trailers" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/AoT2-Switch-Vita_01-19-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Attack on Titan 2" srcset="https://gematsu.com/wp-content/uploads/2018/01/AoT2-Switch-Vita_01-19-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/AoT2-Switch-Vita_01-19-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/koei-tecmo-attack-titan-2-switch-ps-vita-gameplay-trailers" title="Koei Tecmo’s Attack on Titan 2 Switch and PS Vita gameplay trailers" rel="bookmark">Koei Tecmo’s Attack on Titan 2 Switch and P...</a></div>
</div>
<div class="clear"></div>
</div>

<div id="gameannounce">
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/hatsune-miku-vr-announced-pc" title="Hatsune Miku VR announced for PC" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Hatsune-Miku-VR_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Hatsune Miku VR" srcset="https://gematsu.com/wp-content/uploads/2018/01/Hatsune-Miku-VR_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Hatsune-Miku-VR_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/hatsune-miku-vr-announced-pc" title="Hatsune Miku VR announced for PC" rel="bookmark">Hatsune Miku VR announced for PC</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/nippon-ichi-software-announces-liar-princess-blind-prince-project-nightmare-disgaea-remake" title="Nippon Ichi Software announces Liar Princess and the Blind Prince, Project Nightmare, and Disgaea remake" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Liar-Princess-Blind-Prince-Ann_01-18-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Liar Princess and the Blind Prince" srcset="https://gematsu.com/wp-content/uploads/2018/01/Liar-Princess-Blind-Prince-Ann_01-18-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Liar-Princess-Blind-Prince-Ann_01-18-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/nippon-ichi-software-announces-liar-princess-blind-prince-project-nightmare-disgaea-remake" title="Nippon Ichi Software announces Liar Princess and the Blind Prince, Project Nightmare, and Disgaea remake" rel="bookmark">Nippon Ichi Software announces Liar Princess ...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/d3-publisher-announces-switch-downloadable-titles-lineup" title="D3 Publisher announces Switch downloadable titles lineup" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/D3P-Switch-Games_01-18-18_001-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="D3 Publisher Switch Games" srcset="https://gematsu.com/wp-content/uploads/2018/01/D3P-Switch-Games_01-18-18_001-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/D3P-Switch-Games_01-18-18_001-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/d3-publisher-announces-switch-downloadable-titles-lineup" title="D3 Publisher announces Switch downloadable titles lineup" rel="bookmark">D3 Publisher announces Switch downloadable ti...</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/gundam-heroes-announced-pc-browser" title="Gundam Heroes announced for PC browser" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Gundam-Heroes_01-17-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Gundam Heroes" srcset="https://gematsu.com/wp-content/uploads/2018/01/Gundam-Heroes_01-17-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Gundam-Heroes_01-17-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/gundam-heroes-announced-pc-browser" title="Gundam Heroes announced for PC browser" rel="bookmark">Gundam Heroes announced for PC browser</a></div>
</div>
<div class="post">
<div class="image"><a href="https://gematsu.com/2018/01/nintendo-labo-build-play-toy-con-kits-announced-switch" title="Nintendo Labo build-and-play Toy-Con kits announced for Switch" rel="bookmark"><img width="165" height="95" src="https://gematsu.com/wp-content/uploads/2018/01/Nintendo-Labo-Ann_01-17-18-165x95.jpg" class="attachment-165x95 size-165x95 wp-post-image" alt="Nintendo Labo" srcset="https://gematsu.com/wp-content/uploads/2018/01/Nintendo-Labo-Ann_01-17-18-165x95.jpg 165w, https://gematsu.com/wp-content/uploads/2018/01/Nintendo-Labo-Ann_01-17-18-50x30.jpg 50w" sizes="(max-width: 165px) 100vw, 165px" /></a></div>
<div class="title"><a href="https://gematsu.com/2018/01/nintendo-labo-build-play-toy-con-kits-announced-switch" title="Nintendo Labo build-and-play Toy-Con kits announced for Switch" rel="bookmark">Nintendo Labo build-and-play Toy-Con kits ann...</a></div>
</div>
<div class="clear"></div>
</div>
</div>
</div>
</div>
</div>
<div id="main">
<div id="content">
<div id="post" class="post-235358">

<div class="singlesection"><div class="label posttitle"></div><div class="clear"></div></div>

<div class="title">The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan</div>

<div class="meta">posted on 12.20.17 at 01:26 AM EST by <a href="https://gematsu.com/author/admin" title="Posts by Sal Romano" rel="author">Sal Romano</a> (<a href="https://twitter.com/salromano" target="_blank">@salromano</a>) </div>

<div class="share">
<div style="float:left;"><div class="pw-server-widget" data-id="wid-pdpho6qr"></div></div>
<div style="float:left;">
<iframe src="https://www.facebook.com/plugins/like.php?href=https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan&width=75&layout=button_count&action=like&size=small&show_faces=false&share=false&height=21&appId=1459602214296103" width="75" height="21" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
</div>
<div class="clear"></div>
</div>

<div class="tagline">First screenshots of the Cold Steel series' final chapter.</div>

<div class="entry">
<p class="aligncenter"><img src="https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17.jpg" alt="The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~" class="alignnone size-full wp-image-235363" srcset="https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17.jpg 600w, https://gematsu.com/wp-content/uploads/2017/12/Sen-no-Kiseki-4-Ann_12-20-17-400x225.jpg 400w" sizes="(max-width: 600px) 100vw, 600px" /></p>
<p>Falcom has officially <a href="https://www.falcom.co.jp/kaisya/ir/pdf/171220.pdf" rel="noopener" target="_blank">announced</a> <em>The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~</em> for PlayStation 4. It will launch in Japan in fall 2018. <span id="more-235358"></span></p>
<p>Here is a brief overview of the game, via Falcom:</p>
<p><strong>(Editor&#8217;s Note: It goes without saying, but any <em>The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~</em>-related information and images may be considered a spoiler for previous titles.)</strong></p>
<blockquote><p>Due to the &#8220;The Great Twilight&#8221; plan being put into effect, a loathsome &#8220;curse&#8221; spread across the empire.</p>
<p>Rean Schwarzer, the &#8220;Ashen Knight,&#8221; was overtaken by his rampaging ogre power and lost self-control.</p>
<p>As the world heads for its demise, what will the remaining members of the new and old Class VII do?</p></blockquote>
<p>According to Falcom, <em>The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~</em> will be the final chapter of <em>The Legend of Heroes: Trails of Cold Steel</em> series, and depict the conclusion of the Erebonian Empire through overwhelming volume and grand scale that surpasses its predecessor, <em>The Legend of Heroes: Trails of Cold Steel III</em>.</p>
<p>View the first set of screenshots <a href="/gallery/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/">at the gallery</a>. Visit the teaser website <a href="https://www.falcom.co.jp/sen4/" target="_blank">here</a>.</p>


<div class="gallery">
<a href="/gallery/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_001.jpg.php"><img src="/gallery/cache/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_001.jpg_140_cw140_ch78.jpg" /></a><a href="/gallery/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_002.jpg.php"><img src="/gallery/cache/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_002.jpg_140_cw140_ch78.jpg" /></a><a href="/gallery/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_003.jpg.php"><img src="/gallery/cache/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/The-Legend-of-Heroes-Trails-of-Cold-Steel-IV-The-End-of-Saga_2017_12-20-17_003.jpg_140_cw140_ch78.jpg" /></a>
<a href="/gallery/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga/december-20-2017/"><div class="visit"><div class="link">visit gallery &raquo;</div></div></a>
 <div class="clear"></div>
</div> </div>

<div id="ingageunit" style="margin: 0 0 15px;"></div>

<div class="category">
<div class="singlesection">

<div class="label">Read More</div>
<div class="clear"></div>
</div>
<a href="https://gematsu.com/c/playstation-4" rel="category tag">PlayStation 4</a>, <a href="https://gematsu.com/c/top" rel="category tag">Top</a>, <a href="https://gematsu.com/tag/falcom" rel="tag">Falcom</a>, <a href="https://gematsu.com/tag/game-announce" rel="tag">Game Announce</a>, <a href="https://gematsu.com/tag/rpg" rel="tag">RPG</a>, <a href="https://gematsu.com/tag/screenshots" rel="tag">Screenshots</a>, <a href="https://gematsu.com/tag/the-legend-of-heroes-trails-of-cold-steel-iv-the-end-of-saga" rel="tag">The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~</a> </div>
</div>

<div id="Play_Asia">
<div class="singlesection">

<div style="float: right; font-size: 11px; text-transform: lowercase; ">Save $3 with the coupon code "GEMATSU"</div>
<div class="label" style="border-color: #979c7b;">Play-Asia</div>
<div class="clear"></div>
</div>
<div id="Play_Asia_Widget"></div>
<script type="text/javascript">
function getRandomUrl(urls) {
    var minIndex = 0;
    var maxIndex = urls.length - 1;
    var randomIndex = Math.floor(Math.random() * (maxIndex - minIndex)) + minIndex;
    return urls[randomIndex];
}

var urls = [
"https://www.play-asia.com/38/190%2C000000%2Cnone%2C0%2C0%2C0%2C0%2Ctrans%2C000000%2Cleft%2C0%2C0-391-811-765-70d10y-062-782i-29420_421_422_523_1592_1607_1667_1669_2355_2359_2363_2367_3149_3151-90ce5p-33iframe_banner-44600px",
"https://www.play-asia.com/38/190%2C000000%2Cnone%2C0%2C0%2C0%2C0%2Ctrans%2C000000%2Cleft%2C0%2C0-391-811-765-70cae-062-782i-293145-90ce5p-33iframe_banner-402-44600px",
"https://www.play-asia.com/38/190%2C000000%2Cnone%2C0%2C0%2C0%2C0%2Ctrans%2C000000%2Cleft%2C0%2C0-391-811-765-70gn5f-062-782i-293143-90ce5p-33iframe_banner-402-44600px",
"https://www.play-asia.com/38/190%2C000000%2Cnone%2C0%2C0%2C0%2C0%2Ctrans%2C000000%2Cleft%2C0%2C0-391-811-765-7084g9-062-782i-293147-90ce5p-33iframe_banner-402-44600px",
"https://www.play-asia.com/38/190%2C000000%2Cnone%2C0%2C0%2C0%2C0%2Ctrans%2C000000%2Cleft%2C0%2C0-391-811-765-709hn4-062-782i-293009-90ce5p-33iframe_banner-401-44600px"];

var randomSelectedUrl = getRandomUrl(urls);

$("#Play_Asia_Widget").html(
"<iframe class='Play_Asia_Widget' src='" + randomSelectedUrl + "' width='600px' height='198px' scrolling='no' frameborder='0'></iframe>");

var t = ""; t += window.location; t = t.replace( /#.*$/g, "" ).replace( /^.*:\/*/i, "" ).replace( /\./g, "[dot]" ).replace( /\//g, "[obs]" ).replace( /-/g, "[dash]" ); t = encodeURIComponent( encodeURIComponent( t ) ); var iframe = document.getElementById( "id01_562613" ); iframe.src = iframe.src.replace( "iframe_banner", t );
</script> </div>
</div>
<div id="sidebar">

<div class="a300">

<div id="div-gpt-ad-1506639509730-1"></div>
</div>


<div id="poststream">
<div class="label">
<span>Story Stream</span>
<div class="border"></div>
</div>
<div class="newerpost">« <a href="https://gematsu.com/2017/12/dissidia-final-fantasy-nt-vaan-lightning-character-trailers" rel="next">Dissidia Final Fantasy NT Vaan and Lightning character trailers</a></div>
<div class="olderpost"><a href="https://gematsu.com/2017/12/super-mario-odyssey-sales-top-one-million-japan-switch-tops-2-98-million" rel="prev">Super Mario Odyssey sales top one million in Japan, Switch tops 2.98 million</a> »</div> </div>

<div id="latestcomments">
<div class="label">Latest Comments</div>
<div id="dsqrecent"><div class="comment alter">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/22461/6545/avatar92.jpg?1515285215" alt="Life&HometownAreBetter" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/oldgameswerebetter/" target="_blank">Life&HometownAreBetter</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287">Open Forum #287</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287#comment-3718146561">one minute ago</a>
</div>
<div class="clear"></div>
</div><div class="comment ">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/11698/9835/avatar92.jpg?1506522812" alt="Max Owlie" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/Cyberpunch/" target="_blank">Max Owlie</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition">Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition#comment-3718145663">2 minutes ago</a>
</div>
<div class="clear"></div>
</div><div class="comment alter">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/2861/8542/avatar92.jpg?1516493098" alt="Zero" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/zerorpg/" target="_blank">Zero</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition">Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition#comment-3718142937">4 minutes ago</a>
</div>
<div class="clear"></div>
</div><div class="comment ">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/2861/8542/avatar92.jpg?1516493098" alt="Zero" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/zerorpg/" target="_blank">Zero</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition">Final Fantasy VII Remake concept art debuts at Final Fantasy 30th Anniversary Exhibition</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/final-fantasy-vii-remake-concept-art-debuts-final-fantasy-30th-anniversary-exhibition#comment-3718141772">5 minutes ago</a>
</div>
<div class="clear"></div>
</div><div class="comment alter">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/9395/1792/avatar92.jpg?1404833368" alt="Nivora" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/nivora/" target="_blank">Nivora</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2">Ys VIII for PC delayed to unannounced date</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/ys-viii-pc-delayed-unannounced-date-2#comment-3718141645">5 minutes ago</a>
</div>
<div class="clear"></div>
</div><div class="comment ">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/6764/4398/avatar92.jpg?1510647615" alt="Kayayday (ZGF :B)" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/ZGamerF/" target="_blank">Kayayday (ZGF :B)</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287">Open Forum #287</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287#comment-3718141411">6 minutes ago</a>
</div>
<div class="clear"></div>
</div><div class="comment alter">
<div class="avatar">
<img src="https://c.disquscdn.com/uploads/users/10867/7890/avatar92.jpg?1516438611" alt="Oracle" />
</div>
<div class="snippet">
<a class="author" href="https://disqus.com/by/disqus_HpJsogdsXO/" target="_blank">Oracle</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287">Open Forum #287</a>
&sdot;
<a class="post" href="https://gematsu.com/2018/01/open-forum-287#comment-3718140302">7 minutes ago</a>
</div>
<div class="clear"></div>
</div></div> <div class="close"><a href="https://gematsu.com/2018/01/open-forum-287" title="Open Forum #287" rel="bookmark">Visit This Week's Open Forum &raquo;</a></div>
</div>



<div class="a300">

<div id="div-gpt-ad-1506639509730-2"></div>
</div>

</div>
<div class="clear"></div>

</div>
<div id="comments">
<div id="disqus_thread">
</div>
<script type="text/javascript">
var disqus_url = 'https://gematsu.com/2017/12/legend-heroes-trails-cold-steel-iv-end-saga-announced-ps4-launches-fall-2018-japan';
var disqus_identifier = '235358 https://gematsu.com/?p=235358';
var disqus_container_id = 'disqus_thread';
var disqus_shortname = 'gematsu';
var disqus_title = "The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan";
var disqus_config_custom = window.disqus_config;
var disqus_config = function () {
    /*
    All currently supported events:
    onReady: fires when everything is ready,
    onNewComment: fires when a new comment is posted,
    onIdentify: fires when user is authenticated
    */
    
    this.page.remote_auth_s3 = 'W10= 899130670d9fc052479f59676a1e5f7981fe20fa 1516493391';
this.page.api_key = 'lJeSSSOGZQc7SZO7n42vPIOtH112NYd3Fvy8AId7AB14KrH69jsAB40KXAlenO8y';
this.sso = {
          name: "Gematsu",
          button: "https://gematsu.com/wp-content/uploads/2017/10/disqus-login.png",
          url: "https://gematsu.com/wp-login.php",
          logout: "https://gematsu.com/wp-login.php?action=logout",
          width: "800",
          height: "700"
    };
    this.language = '';
    
    if (disqus_config_custom) {
        disqus_config_custom.call(this);
    }
};

(function() {
    var dsq = document.createElement('script'); dsq.type = 'text/javascript';
    dsq.async = true;
    dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
})();
</script>
<div id="sidebar">

<div class="a300">

<div id="div-gpt-ad-1506639509730-3"></div>
</div>

<div style="margin: 0 0 20px;">
<div class="singlesection">

<div class="label">Commenting Guidelines</div>
<div class="clear"></div>
</div>
Please read our <a href="/commenting-guidelines/"><span style="color: #005382;">Community Guidelines</span></a> before commenting on an article.
<br><br>
When posting a comment with spoilers, please use the <strong>&lt;spoiler&gt;&lt;/spoiler&gt;</strong> tag.
<br><br>
For questions, please <a href="/contact-mod/"><span style="color: #005382;">contact a mod</span></a>.
</div>
</div>
<div class="clear"></div>
<div class="clear"></div>

</div>
<div id="footer">
<div class="containwidth">
<div class="left">
© Copyright Gematsu 2008-2018. All rights reserved. Reproduction in whole or in part in any form or medium without acknowledgment of Gematsu is prohibited. Use of this site is governed by all applicable laws.
</div>
<div class="right">

<div class="follow">
<a href="/rss/" target="_blank"><img src="https://gematsu.com/wp-content/themes/2014/images/follow_rss.png" title="RSS Feed" style="margin: 0 5px 0 0;"></a>
<a href="https://www.facebook.com/pages/Gematsu/112250142147853" target="_blank"><img src="https://gematsu.com/wp-content/themes/2014/images/follow_facebook.png" title="Facebook" style="margin: 0 5px 0 0;"></a>
<a href="https://twitter.com/gematsucom" target="_blank"><img src="https://gematsu.com/wp-content/themes/2014/images/follow_twitter.png" title="Twitter" style="margin: 0 5px 0 0;"></a>
<a href="https://youtube.com/scrawlfx" target="_blank"><img src="https://gematsu.com/wp-content/themes/2014/images/follow_youtube.png" title="YouTube" style="margin: 0 5px 0 0;"></a>
<a href="https://www.newsnow.co.uk/nn/Scrawl" target="_blank"><img src="https://gematsu.com/wp-content/themes/2014/images/newsnow.png" title="NewsNow"></a>
</div>

<a href="/advertising/">Advertising</a> ·
<a href="/commenting-guidelines/">Comment Guidelines</a> ·
<a href="/follow/">Social Media</a> ·
<a href="/staff/">Staff</a> ·
<a href="/about/">About</a> ·
<a href="/privacy/">Privacy</a>
</div>
<div class="clear"></div>

<div id="a728" class="advertisement">
<div class="a728">

<div id="div-gpt-ad-1506639509730-5"></div>
</div>
</div>
</div>
</div>

</div>
<script type="text/javascript">
        // <![CDATA[
        var disqus_shortname = 'gematsu';
        (function () {
            var nodes = document.getElementsByTagName('span');
            for (var i = 0, url; i < nodes.length; i++) {
                if (nodes[i].className.indexOf('dsq-postid') != -1 && nodes[i].parentNode.tagName == 'A') {
                    nodes[i].parentNode.setAttribute('data-disqus-identifier', nodes[i].getAttribute('data-dsqidentifier'));
                    url = nodes[i].parentNode.href.split('#', 1);
                    if (url.length == 1) { url = url[0]; }
                    else { url = url[1]; }
                    nodes[i].parentNode.href = url + '#disqus_thread';
                }
            }
            var s = document.createElement('script');
            s.async = true;
            s.type = 'text/javascript';
            s.src = '//' + disqus_shortname + '.disqus.com/count.js';
            (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
        }());
        // ]]>
        </script>
<script type="text/javascript">!function(t,e){"use strict";function n(){if(!a){a=!0;for(var t=0;t<d.length;t++)d[t].fn.call(window,d[t].ctx);d=[]}}function o(){"complete"===document.readyState&&n()}t=t||"docReady",e=e||window;var d=[],a=!1,c=!1;e[t]=function(t,e){return a?void setTimeout(function(){t(e)},1):(d.push({fn:t,ctx:e}),void("complete"===document.readyState||!document.attachEvent&&"interactive"===document.readyState?setTimeout(n,1):c||(document.addEventListener?(document.addEventListener("DOMContentLoaded",n,!1),window.addEventListener("load",n,!1)):(document.attachEvent("onreadystatechange",o),window.attachEvent("onload",n)),c=!0)))}}("wpBruiserDocReady",window);
			(function(){var wpbrLoader = (function(){var g=document,b=g.createElement('script'),c=g.scripts[0];b.async=1;b.src='https://gematsu.com/?gdbc-client=3.1.12-'+(new Date()).getTime();c.parentNode.insertBefore(b,c);});wpBruiserDocReady(wpbrLoader);window.onunload=function(){};window.addEventListener('pageshow',function(event){if(event.persisted){(typeof window.WPBruiserClient==='undefined')?wpbrLoader():window.WPBruiserClient.requestTokens();}},false);})();
</script><script type='text/javascript' src='https://gematsu.com/wp-content/themes/2014/js/jquery.idTabs.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201803'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pollsL10n = {"ajax_url":"https:\/\/gematsu.com\/wp-admin\/admin-ajax.php","text_wait":"Your last request is still being processed. Please wait a while ...","text_valid":"Please choose a valid poll answer.","text_multiple":"Maximum number of choices allowed: ","show_loading":"0","show_fading":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://gematsu.com/wp-content/plugins/wp-polls/polls-js.js?ver=2.73.8'></script>
<script type='text/javascript' src='https://gematsu.com/wp-includes/js/wp-embed.min.js?ver=4.9.2'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201803.js' async defer></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:5.7',blog:'7062773',post:'235358',tz:'-5',srv:'gematsu.com'} ]);
	_stq.push([ 'clickTrackerInit', '7062773', '235358' ]);
</script>
</body>

<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-28470928-1']);
	_gaq.push(['_trackPageview']);

	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
</script>
</html>
