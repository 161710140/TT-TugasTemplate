@extends('layouts.gal')
@section('konten')
<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      </ol>
      <div class="carousel-inner">
        <div class="item active">
          <img src="11.jpg">
          <div class="container">
            <div class="carousel-caption">
              <h1>Welcome to the Gallery!!!</h1>
            </div>
          </div>
        </div>
            </div>
          </div>
        </div>
        <center>
        <u><h2>Fate Grand Order</h2></u>
        </center>
<img src="qa.jpg" class="img-rounded" alt="d" width="150px" height="150px">&nbsp&nbsp&nbsp
<img src="qs.jpg" class="img-rounded" alt="a" width="150px" height="150px">&nbsp&nbsp&nbsp
<img src="qd.jpg" class="img-rounded" alt="b" width="150px" height="150px">&nbsp&nbsp&nbsp
<img src="qf.jpg" class="img-rounded" alt="c" width="150px" height="150px">&nbsp&nbsp&nbsp
<img src="qg.png" class="img-rounded" alt="e" width="150px" height="150px">&nbsp&nbsp&nbsp
<img src="q.jpg" class="img-rounded" alt="f" width="150px" height="150px">&nbsp&nbsp&nbsp
<center>
<u><h2>Tokyo Xanadu</h2></u>
</center>
<img src="x.png" width="150px" height="150px" class="img-rounded">
<img src="xa.png" width="150px" height="150px" class="img-rounded">
<img src="xc.png" width="150px" height="150px" class="img-rounded">
<img src="xd.png" width="150px" height="150px" class="img-rounded">
<img src="xs.png" width="150px" height="150px" class="img-rounded">
<img src="xf.jpg" width="150px" height="150px" class="img-rounded">
<img src="xg.jpg" width="150px" height="150px" class="img-rounded">
<center>
<u><h2>Illustration</h2></u>
</center>
<img src="1.jpg"  width="150px" height="150px" class="img-rounded">
<img src="2.jpg" width="150px" height="150px" class="img-rounded">
<img src="3.jpg" width="150px" height="150px" class="img-rounded">
<img src="4.jpg" width="150px" height="150px" class="img-rounded">
<img src="5.jpg" width="150px" height="150px" class="img-rounded">
<img src="6.jpg" width="150px" height="150px" class="img-rounded">
<img src="7.jpg" width="150px" height="150px" class="img-rounded">
@endsection