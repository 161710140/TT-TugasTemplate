@extends('layouts.para')
@section('konten')

<div class="jumbotron">

	<center>

		<img src="otk.jpg" width="280px" height="280px">
		<br>
<br>
		Otaku (おたく/オタク?) adalah istilah bahasa Jepang yang digunakan untuk menyebut orang yang betul-betul menekuni hobi.

Sejak paruh kedua dekade 1990-an, istilah Otaku mulai dikenal di luar Jepang untuk menyebut penggemar berat subkultur asal Jepang seperti anime dan manga, bahkan ada orang yang menyebut dirinya sebagai Otaku.

Otaku berasal dari sebuah istilah bahasa Jepang yang merujuk kepada rumah atau keluarga orang lain (お宅/御宅, otaku). Kata ini sering digunakan sebagai metafora untuk honorifik kata ganti orang kedua. Dalam kasus ini, terjemahannya adalah "Anda". Sebagai contoh, dalam anime Macross, ditayangkan pertama kali pada tahun 1982, tokoh Lynn Minmay menggunakan istilah ini sebagai kata ganti.[1][2]

Bentuk slang modern dari otaku ditulis sepenuhnya dengan aksara hiragana (おたく) atau katakana (オタク, atau yang lebih jarang, ヲタク) untuk membedakan dengan makna terdahulunya. Istilah ini kemungkinan besar berasal dari percakapan antar penggemar anime yang selalu menyapa lawan bicara dengan sebutan Otaku (お宅 Anda?).

Otaku berasal dari sebuah istilah bahasa Jepang yang merujuk kepada rumah atau keluarga orang lain (お宅/御宅, otaku). Kata ini sering digunakan sebagai metafora untuk honorifik kata ganti orang kedua. Dalam kasus ini, terjemahannya adalah "Anda". Sebagai contoh, dalam anime Macross, ditayangkan pertama kali pada tahun 1982, tokoh Lynn Minmay menggunakan istilah ini sebagai kata ganti.[1][2]

Bentuk slang modern dari otaku ditulis sepenuhnya dengan aksara hiragana (おたく) atau katakana (オタク, atau yang lebih jarang, ヲタク) untuk membedakan dengan makna terdahulunya. Istilah ini kemungkinan besar berasal dari percakapan antar penggemar anime yang selalu menyapa lawan bicara dengan sebutan Otaku (お宅 Anda?).
	
</div>
</center>
@endsection