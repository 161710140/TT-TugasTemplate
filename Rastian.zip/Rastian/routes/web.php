<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('depan', function () {
    return view('hom');
});
Route::get('parag', function () {
    return view('blog');
});
Route::get('Data', function () {
    return view('database');
    });
Route::get('gambar', function () {
    return view('gambar');
});
Route::get('news', function () {
    return view('GameNews');
});
Route::get('FGO', function () {
    return view('FGO');
});
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/a', 'RastianController@siswa');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
