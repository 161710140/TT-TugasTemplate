<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>MENU UTAMA</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

  </head>
  <body>
  <br>
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a href="#"><button type="button" class="btn btn-primary btn-lg" >
      <span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home
      </button></a>&nbsp;
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">

      <a href="/uts/pendaftar/lihatdata.php"><button type="button" class="btn btn-info btn-lg" >
      <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Pendaftar
      </button></a>

      <a href="/uts/jurusan/lihatdata.php"><button type="button" class="btn btn-primary btn-lg" > 
      <span class="glyphicon glyphicon-road" aria-hidden="true"></span> Jurusan
      </button></a>

      <a href="/uts/penguji/lihatdata.php"><button type="button" class="btn btn-warning btn-lg" >
      <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Penguji
      </button></a>

      <a href="/uts/kepsek/lihatdata.php"><button type="button" class="btn btn-danger btn-lg" >
      <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Kepala Sekolah
      </button></a>

      <a href="/uts/hasil/lihatdata.php"><button type="button" class="btn btn-success btn-lg" >
       <span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Hasil
      </button></a>

      <a href="pengumuman"><button type="button" class="btn btn-primary btn-lg" >
      <span class="glyphicon glyphicon-bullhorn" aria-hidden="true"></span> Pengumuan
      </button></a>&nbsp;
       </div> 
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

  <div class="col-md-12">
    <div class="container">
      <div class="row">
        <div class="panel panel-primary">
          <div class="panel-heading"></div>
          <div class="panel-body">
            <center><h1>~Selamat Datang Di Pendaftaran Siswa Baru~</h1></center>
            <center><img src="logo.jpg" width="150px" height="150px">
            <h3>SMK ASSALAAM BANDUNG</h3>
            <h4>2017-2018</h4>
            </center>
          </div>
        </div>
      </div>
    </div>
  </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>