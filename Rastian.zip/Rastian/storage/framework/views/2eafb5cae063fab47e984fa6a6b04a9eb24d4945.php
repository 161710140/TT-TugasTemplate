<?php $__env->startSection('konten'); ?>
<div class="jumbotron">
        <h2>Gallery!!</h2>
        <p>You can see my gallery</p>
        <p><a href="Photo" a class="btn btn-primary btn-md" role="button">Click Here!! &raquo;</a></p>
      </div>
      </a>
    </div>
    <div class="jumbotron">
        <h2>Database</h2>
        <p>This is the database</p>
        <p><a href="data" a class="btn btn-primary" role="button">Click Here!! &raquo;</a></p>
      </div>
      </a>
    </div>
    <div class="jumbotron">
        <h2>Paragraph</h2>
       <p>Paragraph Corner!!</p>
        <p><a href="parag" a class="btn btn-primary btn-md" role="button">Click Here!! &raquo;</a></p>
      </div>
      </a>
    </div>
    <div class="jumbotron">
        <h2>History</h2>
        <p>History Corner!!</p>
        <p><a href="histo" a class="btn btn-primary btn-md" role="button">Click Here!! &raquo;</a></p>
      </div>
      </a><
    </div>
    <div class="jumbotron">
        <h2>Game News</h2>
        <p>Game news Corner</p>
        <p><a href="news" a class="btn btn-primary btn-md" role="button">Click Here &raquo;</a></p>
      </div>
      </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.headhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>