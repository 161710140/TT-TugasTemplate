<?php $__env->startSection('konten'); ?>
<img src="img/1.jpg" class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="img/2.jpg" class="img-rounded" alt="a">&nbsp&nbsp&nbsp
<img src="img/3.jpg" class="img-rounded" alt="b">&nbsp&nbsp&nbsp
<img src="img/4.jpg" class="img-rounded" alt="c">&nbsp&nbsp&nbsp
<img src="img/5.jpg" class="img-rounded" alt="e">&nbsp&nbsp&nbsp
<img src="img/6.jpg" class="img-rounded" alt="f">&nbsp&nbsp&nbsp
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.headgallery', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>