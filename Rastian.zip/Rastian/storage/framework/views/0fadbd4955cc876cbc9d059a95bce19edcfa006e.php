<footer>
        <hr><p align="right">--RIZAL PRADANA--&nbsp&nbsp&nbsp</p>
        <hr><p align="right">© Company 2018&nbsp&nbsp&nbsp</p>
      </footer>