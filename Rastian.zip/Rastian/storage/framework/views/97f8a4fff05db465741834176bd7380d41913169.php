<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('BS/examples/starter-template/starter-template.css')); ?>">		 
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-theme.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-theme.min.css')); ?>">
	<?php echo $__env->make('template.paragraph', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('konten'); ?>
	<br>
</body>
</html>