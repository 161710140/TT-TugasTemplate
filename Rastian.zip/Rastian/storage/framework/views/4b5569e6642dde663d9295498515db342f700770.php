<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="container">
	<table border="2" class="tables">
        <th>Id</th>
        <th>Nis</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Tempat Lahir</th>
        <th>Cita-Cita</th>
        <th>Tanggal lahir</th>
        <th>Hobi</th>
        <th>Foto</th>
   <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
 	<td><?php echo e($gg -> id); ?></td>
 	<td><?php echo e($gg -> nis); ?></td>
 	<td><?php echo e($gg -> nama_siswa); ?></td>
 	<td><?php echo e($gg -> alamat); ?></td>
 	<td><?php echo e($gg -> tempat_lahir); ?></td>
 	<td><?php echo e($gg -> cita_cita); ?></td>
 	<td><?php echo e($gg -> tanggal_lahir); ?></td>
 	<td><?php echo e($gg -> hobi); ?></td>
    <td><img src="<?php echo e(asset('img/'.$gg->foto)); ?>" style="max-height: 150px;max-width: 150px;margin-top: 10px;"></td>
 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</table>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.a', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>