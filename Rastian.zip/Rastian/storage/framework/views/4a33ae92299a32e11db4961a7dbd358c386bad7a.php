<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
nama:sandika erlangga<br>
umur:16<br>
alamat:cibaduyut<br>
ttl:bandung.26 juni 2001<br>
hobi:musik<br>
cita cita:gitaris<br>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.a', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>