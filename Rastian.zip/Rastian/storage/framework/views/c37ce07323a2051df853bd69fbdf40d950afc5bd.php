<?php $__env->startSection('konten'); ?>

<div class="singlesection"><div class="label posttitle"></div><div class="clear"></div></div>

<div class="title">The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>