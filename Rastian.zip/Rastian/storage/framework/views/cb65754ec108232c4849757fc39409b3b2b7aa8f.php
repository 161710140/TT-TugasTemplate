<footer>
        <hr><p align="right">© Company 2018&nbsp&nbsp&nbsp</p>
      </footer>