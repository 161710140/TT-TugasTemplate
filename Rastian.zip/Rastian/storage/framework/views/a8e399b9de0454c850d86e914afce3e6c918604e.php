<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
<div class="jumbotron">
       <center><h1>Hello, selamat datang!</h1></center>
        <p></p>
      </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>