<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
	<center><h1>"Saya lebih baik di benci sebagai diriku sebenarnya ketimbang munafik untuk di sukai orang lain"</h1></center>
	<center><h1>NIRVANA</h1></center>
<img src="img/1.jpg" class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="img/2.jpg" class="img-rounded" alt="a">&nbsp&nbsp&nbsp
<img src="img/3.jpg" class="img-rounded" alt="b">&nbsp&nbsp&nbsp
<img src="img/4.jpg" class="img-rounded" alt="c">&nbsp&nbsp&nbsp
<img src="img/5.jpg" class="img-rounded" alt="e">&nbsp&nbsp&nbsp
<img src="img/6.jpg" class="img-rounded" alt="f">&nbsp&nbsp&nbsp

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.a', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>