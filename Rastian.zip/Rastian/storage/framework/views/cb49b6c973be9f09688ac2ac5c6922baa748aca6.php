<?php $__env->startSection('konten'); ?>

<br>
<br>
 <div class="blog-header">
 <center>
 <br>
 <br>
        <h3 class="title">The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ announced for PS4, launches fall 2018 in Japan</h3>
        </center>
         </div>
        <p class="lead blog-description"></p>
         <div class="row">

        <div class="col-sm-8 blog-main">
<center>
<img src="logo.png" width="450px" height="250px" style="position: absolute;right: 250">
      <br>
      <br>

      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      </center>
      <center>
<p> Falcom has officially announced The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ for PlayStation 4. It will launch in Japan in fall 2018. 
</p>
<br>
<br>
<p>According to Falcom, The Legend of Heroes: Trails of Cold Steel IV ~The End of Saga~ will be the final chapter of The Legend of Heroes: Trails of Cold Steel series, and depict the conclusion of the Erebonian Empire through overwhelming volume and grand scale that surpasses its predecessor, The Legend of Heroes: Trails of Cold Steel III.</p>
<p>
	<br>
	<br>
	<img src="15.jpg" width="450px" height="250px">
	<br>
Here are some highlights from the interview:
 <center>
 <img src="ren.png" style="position: absolute;right: -500px;top: 300px">
<img src="render.png" width="500px" height="707px" style="position: absolute;top: 1200px ;right:-500px">
 </center>
 <br>
<li circle><i>
The Legend of Heroes: Trails of Cold Steel IV: The End of Saga is an important title that will serve as a stopping point to the Trails of Cold Steel saga that is part of  the Sen saga that started in 2004.</i></li>
 <br>
 <br>
<li circle><i>Therefore, the subtitle “The End of Saga” was given. The title logo is an image that reflects elements from the entire Trails series as well.
</i>
</li>
<br>
 <br>
<li circle><i>The decision to end here was made around the time of The Legend of Heroes: Trails in the Sky FC.
</i>
</li>
<br>
 <br>
<li circle><i>This is the first time the company has announced a new title as a last title, so Falcom feels the pressure.
</i>
</li>
<br>
 <br>
<li circle><i>One thing you’ll wonder about is at what point in time did the story start, but another one Kondo wants you to think about is if Rean Schwarzer is the protagonist in the first place.
</i>
</li>
 <br>
 <br>
<li circle><i>Lloyd Bannings and the others are heading to the ending that was talked about in the last part of The Legend of Heroes: Ao no Kiseki.
</i>
</li>
<br>
 <br>
<li circle><i>The Legend of Heroes: Trails of Cold Steel IV will have more playable characters than the previous title, and the most there’s ever been.
</i>
</li>
<br>
 <br>
<li circle><i>It’ll be an RPG with exceptional volume from start to end.
</i>
</li>
<br>
 <br> 
<li circle><i>Falcom plans to brush up a more complete battle system that inherits elements from the previous title in “Brave Order” and “Break.”
</i>
</li>
 <br>
 <br>
<li circle><i>With characters appearing from past titles, Falcom is looking to show off each and every character, and they’re focusing on developing it to tell its story as if it were a single RPG title of its own.
</i>
</li>
 <br>
 <br>
<li circle><i>Development is currently 45% complete.
</center>
</i>
</li>
</p>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>