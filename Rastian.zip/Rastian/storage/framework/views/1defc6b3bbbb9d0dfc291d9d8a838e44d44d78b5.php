<!DOCTYPE html>
<html>
<head>
	<title>Paragraph</title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('BS/examples/carousel/carousel.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('BS/examples/blog/blog.css')); ?>">		 
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-theme.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-theme.min.css')); ?>">
	<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('konten'); ?>
	<br>
</body>
</html>