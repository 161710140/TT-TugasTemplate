<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
&nbsp&nbsp&nbsp Nama : Rizal Pradana<br>
&nbsp&nbsp&nbsp Umur : 16 tahun<br>
&nbsp&nbsp&nbsp TTL  : BANDUNG,13 FEBUARI 2001<br>
&nbsp&nbsp&nbsp Jenis klamin : Laki-laki<br>
&nbsp&nbsp&nbsp Sekolah : SMK ASSALAAM BANDUNG<br>
&nbsp&nbsp&nbsp Kelas : XI Rpl 1<br>
&nbsp&nbsp&nbsp Jurusan : RPL<br>
&nbsp&nbsp&nbsp Hobi : badminton<br>
&nbsp&nbsp&nbsp Cita-cita : insyaalloh jadi programmer<br>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>