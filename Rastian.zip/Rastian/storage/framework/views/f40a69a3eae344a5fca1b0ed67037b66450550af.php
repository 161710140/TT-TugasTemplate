<?php $__env->startSection('konten'); ?>
<div class="col-md-12">
    <div class="container">
      <div class="row">
        <div class="panel panel-primary">
          <div class="panel-heading"></div>
          <div class="panel-body">
            <center><h1>Welcome!!</h1></center>
            <center><img src="14.GIF" width="150px" height="150px">
            <img src="lo.jpg" width="260px" height="350px" style="position: absolute;right:1000px;top: 130px">
            <img src="log.png" width="250px" height="350px" style="position: absolute;left:900px;top: 130px">
           <h2>Gallery</h2>
              <a href="gambar" button type="button" class="btn btn-primary">Click Here!</a>
              </center>
              <h2 style="position: absolute;top: 260px;right: 430px">Database</h2>
             <a style="position: absolute;top: 320px;right: 440px" href="data" button type="button" class="btn btn-primary">Click Here!</a>
             <h2 style="position: absolute;top: 255px;left:360px">Paragraph</h2>
             <a style="position: absolute;top: 320px; left:375px" href="parag" button type="button" class="btn btn-primary">Click Here!</a>
             <br>
             <center>
              <h2>Game News </h2>
              <a href="news" button type="button" class="btn btn-primary">Click Here!</a>
              </center>
              <h2 style="position: absolute;top: 375px;left:370px">FGO</h2>
             <a style="position: absolute;top: 435px; left:375px" href="FGO" button type="button" class="btn btn-primary">Click Here!!</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.headhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>