<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body background="img/2.jpg">
<div class="jumbotron">
       <center><h1>assalamualaikum,saya disini cuman belajar, mohon dimaklumi !</h1></center>
        <p></p>
      </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.a', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>