<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
	
	<h1 id="judul1"> motogp</h1><br><br>
<p>Grand Prix Sepeda Motor (MotoGP) mengacu pada kelas puncak dari balap motor, saat ini terbagi dalam tiga kelas mesin yang berbeda: Moto3,Moto2 dan MotoGP.Motor-motor yang digunakan di MotoGP adalah motor yang dibuat khusus untuk balapan dan tidak dijual untuk umum. Hal ini berlawanan dengan beberapa balapan kategori produksi,seperti World Superbike yang melombakan versi modifikasi dari motor yang tersedia untuk umum.<br>
<img src="img/d.png" align="left"/>


<h1>Spesifikasi mesin</h1><br>

    Konfigurasi: V4, V-twin, atau 4-silinder (Kelas MotoGP), 4-silinder (Kelas Moto2), 1-silinder (Kelas Moto3)<br>
    Kapasitas: 1000 cc (Kelas MotoGP), 600 cc (kelas Moto 2), 250 cc (kelas Moto3)<br>
    Katup: 16-katup (Untuk semua kelas)<br>
    Kerja katup: DOHC, 4-katup per silinder (Untuk semua kelas)<br>
    Bahan bakar: Tanpa timbal (tidak ada bahan bakar kontrol), 100 oktan<br>
    Pasokan bahan bakar: Injeksi bahan bakar<br>
    Aspirasi: Aspirasi normal<br>
    Kekuatan: Kira - kira 250 atau 225 dk<br>
    Pelumasan: Basah<br>
    Maksimum/minimum putaran mesin: 17500 - 18000 Rotasi per menit atau 300 putaran per detik
    Pendingin: Pompa air tunggal<br>


<h1>Perubahan Penting Regulasi</h1>

    Pada tahun 2002, kelas 500 cc digantikan menjadi MotoGP, kapasitas motor yaitu 990 cc.
    Pada tahun 2005, sebuah peraturan baru untuk MotoGP telah diberlakukan yaitu flag-to-flag. Sebelumnya, jika sebuah balapan dimulai dengan start dalam kondisi sirkuit kering dan hujan turun, pembalap terdepan dapat mengangkat tangan untuk menghentikan lomba, demikian juga dengan para ofisial mengibarkan bendera merah untuk menghentikan balapan, kemudian balapan dimulai lagi dengan menggunakan ban basah. Sekarang jika hujan turun saat balapan tidak ada lagi bendera merah, para pembalap langsung menuju pit untuk mengganti ban sesuai kebijakan tim.

    Pada tahun 2007, kelas MotoGP diturunkan kapasitas mesinnya, menjadi 800 cc.

    Pada tahun 2010, kelas MotoGP diberlakukan pembatasan mesin 6 mesin untuk 1 musim.

    Pada tahun 2010, kelas 250 cc digantikan oleh kelas Moto2 dengan basis mesin Honda CBR600RR dan sasis prototipe.

    Pada tahun 2012, kelas MotoGP dinaikkan kapasitas mesinnya, menjadi 1.000 cc.

    Pada tahun 2012, kelas MotoGP diberlakukan regulasi CRT (Claiming Rule Team) yang memperbolehkan Tim (Kecuali Team Pabrikan) memakai mesin motor massal 1.000 cc disasis prototipe.

    Pada tahun 2012, kelas 125 cc digantikan oleh kelas Moto3 dengan mesin 250 cc.

    Pada tahun 2014, Kelas CRT di MotoGP diganti menjadi Open Class dan diterapkan sistem kualifikasi Knockout[1]

    Pada tahun 2016 pergantian penggunaan ban dari Bridgestone ke Michelin

    Pada tahun 2016 semua tim MotoGP mulai dari Honda, Yamaha, Ducati dan yg lainnya akan menggunakan 1 ECU seragam buatan Magneti Marelli oleh Dorna. Selain itu, perangkat keselamatan juga di terapkan dengan menambah Sensor Tekanan ban dan Aturan baru[2] yakni penambahan Panel Stewards untuk membantu Race Direction.
    Mulai tahun 2017 penggunaan winglet dilarang, menyusul rilis yang dikeluarkan oleh komisi grandprix pada tanggal 25 Juni 2016 atas pertimbangan keamanan.</p>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>