<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
	<img src="img/4.jpg">
	<h1 id="judul1"> kurt cobain</h1><br><br>
	Kurt Donald Cobain (lahir di Aberdeen, 20 Februari 1967 – meninggal di Seattle, 6 April 1994 pada umur 27 tahun) adalah penyanyi, penulis lagu dan gitaris dalam band grunge dari Seattle, Nirvana. Dengan suksesnya grup musik ini, Cobain menjadi selebriti nasional dan internasional, suatu posisi yang disandangnya dengan berat hati.

Pada 1991, melejitnya lagu Cobain yang paling terkenal, Smells Like Teen Spirit, menandai bermulanya perubahan besar dalam musik pop dari jenis musik yang populer pada tahun 1980-an seperti glam metal, arena rock, dan dance-pop menjadi grunge dan rock alternatif. Selain itu lagu-lagu tulisan Cobain lainnya misalnya About a Girl, Come as You Are, In Bloom, Lithium, Heart-Shaped Box, All Apologies, dan Rape Me.

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.a', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>