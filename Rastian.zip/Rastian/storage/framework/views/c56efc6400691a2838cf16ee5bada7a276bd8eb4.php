<?php $__env->startSection('konten'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>tugas</title>
</head>
<body>
<img src="img/d.png" class="img-rounded" alt="d">&nbsp&nbsp&nbsp
<img src="img/a.jpg" class="img-rounded" alt="a">&nbsp&nbsp&nbsp
<img src="img/b.jpg" class="img-rounded" alt="b">&nbsp&nbsp&nbsp
<img src="img/c.jpg" class="img-rounded" alt="c">&nbsp&nbsp&nbsp
<img src="img/e.jpg" class="img-rounded" alt="e">&nbsp&nbsp&nbsp
<img src="img/f.jpg" class="img-rounded" alt="f">&nbsp&nbsp&nbsp
<img src="img/g.jpg" class="img-rounded" alt="g">&nbsp&nbsp&nbsp
<img src="img/h.jpg" class="img-rounded" alt="h">&nbsp&nbsp&nbsp
<img src="img/i.jpg" class="img-rounded" alt="i">&nbsp&nbsp&nbsp
<img src="img/j.jpg" class="img-rounded" alt="j">&nbsp&nbsp&nbsp
<img src="img/k.jpg" class="img-rounded" alt="k">&nbsp&nbsp&nbsp
<img src="img/l.jpg" class="img-rounded" alt="l">&nbsp&nbsp&nbsp

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>