<?php

use Illuminate\Database\Seeder;

class tugasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $a=[
        	['nis'=>'16171012','nama_siswa'=>'Rastian','alamat'=>'Permata Kopo','tempat_lahir'=>'bandung','cita_cita'=>'Jadi Orang','tanggal_lahir'=>'2001-01-25','hobi'=>'bernafas','foto'=>'qa.jpg'	]
        ];
        DB::table('siswas')->insert($a);
    }
}
